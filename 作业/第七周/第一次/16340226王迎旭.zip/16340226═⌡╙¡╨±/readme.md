###signup.js signup.html signup_css.css 是登陆界面的设计
###information.html info_css.css 是用户信息显示界面的设计
###main.js是nodejs的可执行文件

###使用node.js 8.9.2版本

###直接在当前目录下打开nodejs输入指令node main.js显示Server has began , please goSignUp:http://localhost:8000字样后即可登陆local

###正则表达式的使用的验证文件放置在node_module中

###information为学生信息的显示，signup为登陆界面
