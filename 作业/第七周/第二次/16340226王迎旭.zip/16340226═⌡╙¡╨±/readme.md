###signup.js signup.html signup_css.css 是登陆界面的设计
###information.html info_css.css 是用户信息显示界面的设计
###main.js是nodejs的可执行文件

###使用node.js 8.9.2版本

###直接在当前目录下打开nodejs输入指令node main.js显示Server has began , please goSignUp:http://localhost:8000字样后即可登陆local

###正则表达式的使用的验证文件放置在node_module中

###在登陆时候如果填的信息符合正则表达式格式的要求，那么注册按钮会从红色变为蓝色，否则一直为红色不可操作状态

###information为学生信息的显示，signup为登陆界面

###设置的提示信息只要没有输入或者输入错误一直存在
