###实现了s1-s4的功能，s2-s4的ring.js文件写上了与之前相比的不同之处

###s5看需求看的有点有点迷，等周一老师讲一下抽时间再做一下

###运行环境 node js 8.9.2 运行之后提示server listen 3000

###s1-s4每个文件夹含有背景图两张，一个index.html 一个ring.css 一个ring.js 一个jquery.js文件

